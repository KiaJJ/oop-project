package com.example.oopproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CreatePostSceneController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    TextArea postCaption;

    @FXML
    TextField postImageUrl;

    public void switchToHomeScene(ActionEvent actionEvent) throws IOException,SQLException {
        addPost();
        Parent root= FXMLLoader.load(getClass().getResource("HomeScene.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public String setTheTime(){
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter currentTimeForEdit = DateTimeFormatter.ofPattern("    HH:mm");
        String formattedTime = currentTime.format(currentTimeForEdit).toString();
        return formattedTime;
    }
    public void addPost() throws SQLException {
        ///SQL:
        //پست با کپشن ()postCaption.getText و آدرس عکس postImageUrl.getText به پست های کاربر با نام کاربری MainController.loggedInUsername اضافه شود
        //دقت شود که زمان ایجاد پست نیز ذخیره شود
        JDBC jdbc = new JDBC();
        jdbc.setInfo("INSERT INTO posts(Text,SenderName,ImageSource,Time) VALUES('"
                +postCaption.getText()+"','"+ MainController.loggedInUsername+"','"
                +postImageUrl.getText()+"','" +setTheTime()+"');");
    }
    public void switchToHomeScene2(ActionEvent actionEvent) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("HomeScene.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
