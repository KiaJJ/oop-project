package com.example.oopproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class CreateNewGroupSceneController {
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    TextField groupName;
    @FXML
    TextField ImagUrl;

    public void addMember(ActionEvent actionEvent) throws IOException {
        openMemberList();
    }
    public void openMemberList() throws IOException {
        Stage stage = new Stage();
        Parent root= FXMLLoader.load(getClass().getResource("MemberListScene.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void submit(ActionEvent actionEvent) throws SQLException, IOException {
        ///SQL
        JDBC jdbc = new JDBC();
        jdbc.setInfo("UPDATE groupChats SET ProfilePictureSource='"+ImagUrl.getText()
                +"',GroupName='"+groupName.getText()+"' WHERE GroupID="
        +MainController.newGroupId+";");
        ///continue
        MainController.groupName= groupName.getText();
        switchToGroupChatScene();

    }
    public void switchToGroupChatScene() throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("GroupChatScene.fxml"));
        stage = (Stage) groupName.getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
