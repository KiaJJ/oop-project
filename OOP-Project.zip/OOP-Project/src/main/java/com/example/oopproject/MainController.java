package com.example.oopproject;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MainController {
    public static String loggedInUsername;
    public static String searchedUsername;
    public static int forwardedMessageId;
    public static boolean isInEditMode=false;
    public static boolean isInEditMode2=false;
    public static int editedMessageId;
    public static int deletedMessageId;
    public static String groupName;
    public static int newGroupId;
    public static boolean inGroupAddMember=false;
    public static boolean isInGroupModeChat=false;
    public static String getAccountType(String userName) throws SQLException {
        JDBC jdbc = new JDBC();
        ResultSet resultSet = jdbc.getInfo("SELECT TypeOfAccount FROM users WHERE UserName='"
                +userName+"';");
        while(resultSet.next()){
            return resultSet.getString(1);
        }
        return "";
    }
}
