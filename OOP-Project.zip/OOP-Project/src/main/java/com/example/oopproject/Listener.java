package com.example.oopproject;

public interface Listener {
    public void onClickListener();
}
