package com.example.oopproject;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class PostTemplateController implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent root;
    public static int likedPostId;
    public static int commentedOnPostId;
    int ID;
    boolean liked = false;
    @FXML
    private ImageView img;

    @FXML
    private Label caption;

    @FXML
    private Label postCreator;

    @FXML
    private Label timePostCreated;
    @FXML
    TextArea comment;

    @FXML
    Label Ad;
    @FXML
    Button detail;
    @FXML
    Label comments;
    @FXML
    Label likes;
    @FXML
    Button likeButton;

    public void setData(String imageAddress , String inputCaption , int id ,
                        String time , String postCreatorUserName
                        , int numberOfLikes , int numberOfComments){
        Image image = new Image(getClass().getResourceAsStream( imageAddress));
        img.setImage(image);
        ID=id;
        caption.setText(inputCaption);
        postCreator.setText(postCreatorUserName);
        timePostCreated.setText(time);
        likes.setText(Integer.toString(numberOfLikes)+" Likes");
        comments.setText(Integer.toString(numberOfComments)+" Comments");
    }
    public void likePost() throws SQLException {
        JDBC jdbc = new JDBC();
            if (!likerUserNameExists(MainController.loggedInUsername)) {
                //add a like in posts table
                int previousLikes = 0;
                ResultSet resultSet = jdbc.getInfo("SELECT NumberOfLikes FROM posts WHERE PostID=" + ID + ";");
                while (resultSet.next()) {
                    previousLikes = resultSet.getInt(1);
                }
                previousLikes++;
                jdbc.setInfo("UPDATE posts SET NumberOfLikes=" + previousLikes + " WHERE PostID=" + ID + ";");
                //add the liker to likes table
                jdbc.setInfo("INSERT INTO likes(LikedOnPostID,LikerUserName) VALUES(" + ID + ",'"
                        + MainController.loggedInUsername + "');");
                likes.setText(Integer.toString(previousLikes) + " Likes");
                //liked = true;

        }
    }
    public boolean  likerUserNameExists(String userName) throws SQLException {
        JDBC jdbc = new JDBC();
        ResultSet resultSet = jdbc.getInfo("SELECT LikerUserName FROM likes WHERE LikedOnPostID="
        +ID+";");
        while (resultSet.next()) {
            if (userName.equals(resultSet.getString(1)))
                return true;
        }
        return false;
    }
    public void commentOnPost() throws SQLException{
        //add the comment to comments table
        JDBC jdbc = new JDBC();
        jdbc.setInfo("INSERT INTO comments(Time,Text,CommentedOnPostID,CommenterUserName)" +
                " VALUES('"+setTheTime()+"','"+comment.getText()+"',"+ID
        +",'"+MainController.loggedInUsername+"');");
        //add to the number of comments
        int previousCommentsNum = 0;
        ResultSet resultSet = jdbc.getInfo("SELECT NumberOfComments FROM posts WHERE PostID=" + ID + ";");
        while (resultSet.next()) {
            previousCommentsNum = resultSet.getInt(1);
        }
        previousCommentsNum++;
        jdbc.setInfo("UPDATE posts SET NumberOfComments=" + previousCommentsNum + " WHERE PostID=" + ID + ";");
        comment.setText("");
        comments.setText(Integer.toString(previousCommentsNum) + " Comments");
    }
    public void showLikes() throws IOException {
        likedPostId=ID;
        Stage stage = new Stage();
        Parent root= FXMLLoader.load(getClass().getResource("ShowLikes.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void showComments() throws IOException {
        commentedOnPostId=ID;
        Stage stage = new Stage();
        Parent root= FXMLLoader.load(getClass().getResource("ShowComments.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void forShowComments(){
        comments.addEventHandler(javafx.scene.input.MouseEvent.MOUSE_PRESSED,
                new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        try {
                            showComments();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }
    public void forShowLikes(){
        likes.addEventHandler(javafx.scene.input.MouseEvent.MOUSE_PRESSED,
                new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        try {
                            showLikes();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }
    public String setTheTime(){
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter currentTimeForEdit = DateTimeFormatter.ofPattern("    HH:mm");
        String formattedTime = currentTime.format(currentTimeForEdit).toString();
        return formattedTime;
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Ad.setVisible(false);
        detail.setVisible(false);
        forShowComments();
        forShowLikes();
    }
    public void hideLikeButton(){
        likeButton.setVisible(false);
    }
    public void justForBusinessAccountInOtherAccountsAndProfile(){
        Ad.setVisible(true);
    }
    public void justForBusinessAccountInProfile(){
        detail.setVisible(true);
    }
}
